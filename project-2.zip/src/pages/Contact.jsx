import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Send, MessageCircle, Facebook, Twitter, Linkedin, Instagram } from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: ''
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitStatus, setSubmitStatus] = useState(null);

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setSubmitStatus(null);

    try {
      // Simulate form submission
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      // In a real application, you would send the form data to contact@bestbrokerradar.com
      console.log('Form submitted to contact@bestbrokerradar.com:', formData);
      
      setSubmitStatus('success');
      setFormData({ name: '', email: '', message: '' });
    } catch (error) {
      setSubmitStatus('error');
    } finally {
      setIsSubmitting(false);
    }
  };

  const fadeInUp = {
    initial: { opacity: 0, y: 30 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-6">
            Get in Touch
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed mb-4">
            Have questions about our broker comparisons or need help finding the right trading platform?
          </p>
          <p className="text-lg text-gray-400 max-w-2xl mx-auto">
            We're here to help you make informed decisions about your trading journey. Reach out to us anytime!
          </p>
        </motion.div>

        <div className="grid lg:grid-cols-3 gap-12">
          {/* Contact Information */}
          <motion.div 
            className="lg:col-span-1"
            variants={staggerContainer}
            initial="initial"
            animate="animate"
          >
            <motion.div 
              className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-xl p-8 backdrop-blur-sm h-fit"
              variants={fadeInUp}
            >
              <h2 className="text-2xl font-bold text-cyan-300 mb-6">Contact Information</h2>
              
              <div className="space-y-6">
                <div className="flex items-start">
                  <div className="bg-cyan-500/20 p-3 rounded-lg mr-4">
                    <Mail className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-cyan-300 mb-1">Email Us</h3>
                    <p className="text-gray-300">contact@bestbrokerradar.com</p>
                    <p className="text-sm text-gray-400 mt-1">We'll respond within 24 hours</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cyan-500/20 p-3 rounded-lg mr-4">
                    <MessageCircle className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-cyan-300 mb-1">Live Support</h3>
                    <p className="text-gray-300">Available Monday - Friday</p>
                    <p className="text-sm text-gray-400 mt-1">9:00 AM - 6:00 PM EST</p>
                  </div>
                </div>

                <div className="flex items-start">
                  <div className="bg-cyan-500/20 p-3 rounded-lg mr-4">
                    <MapPin className="w-5 h-5 text-cyan-400" />
                  </div>
                  <div>
                    <h3 className="font-semibold text-cyan-300 mb-1">Location</h3>
                    <p className="text-gray-300">Global Service</p>
                    <p className="text-sm text-gray-400 mt-1">Serving traders worldwide</p>
                  </div>
                </div>
              </div>

              {/* Social Media Links */}
              <div className="mt-8 pt-6 border-t border-cyan-500/20">
                <h3 className="font-semibold text-cyan-300 mb-4">Follow Us</h3>
                <div className="flex space-x-4">
                  <a 
                    href="#" 
                    className="bg-cyan-500/20 p-3 rounded-lg hover:bg-cyan-500/30 transition-all duration-300 group"
                    aria-label="Facebook"
                  >
                    <Facebook className="w-5 h-5 text-cyan-400 group-hover:text-cyan-300" />
                  </a>
                  <a 
                    href="#" 
                    className="bg-cyan-500/20 p-3 rounded-lg hover:bg-cyan-500/30 transition-all duration-300 group"
                    aria-label="Twitter"
                  >
                    <Twitter className="w-5 h-5 text-cyan-400 group-hover:text-cyan-300" />
                  </a>
                  <a 
                    href="#" 
                    className="bg-cyan-500/20 p-3 rounded-lg hover:bg-cyan-500/30 transition-all duration-300 group"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="w-5 h-5 text-cyan-400 group-hover:text-cyan-300" />
                  </a>
                  <a 
                    href="#" 
                    className="bg-cyan-500/20 p-3 rounded-lg hover:bg-cyan-500/30 transition-all duration-300 group"
                    aria-label="Instagram"
                  >
                    <Instagram className="w-5 h-5 text-cyan-400 group-hover:text-cyan-300" />
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>

          {/* Contact Form */}
          <motion.div 
            className="lg:col-span-2"
            variants={fadeInUp}
            initial="initial"
            animate="animate"
          >
            <div className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-xl p-8 backdrop-blur-sm">
              <h2 className="text-2xl font-bold text-cyan-300 mb-6">Send us a Message</h2>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-sm font-medium text-cyan-300 mb-2">
                      Your Name *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-slate-800/50 border border-cyan-500/30 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-300"
                      placeholder="Enter your full name"
                    />
                  </div>
                  <div>
                    <label htmlFor="email" className="block text-sm font-medium text-cyan-300 mb-2">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleInputChange}
                      required
                      className="w-full px-4 py-3 bg-slate-800/50 border border-cyan-500/30 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-300"
                      placeholder="your.email@example.com"
                    />
                  </div>
                </div>

                <div>
                  <label htmlFor="message" className="block text-sm font-medium text-cyan-300 mb-2">
                    Message *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleInputChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 bg-slate-800/50 border border-cyan-500/30 rounded-lg text-gray-300 placeholder-gray-500 focus:outline-none focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20 transition-all duration-300 resize-vertical"
                    placeholder="Tell us how we can help you find the perfect trading platform..."
                  ></textarea>
                </div>

                {/* Submit Status Messages */}
                {submitStatus === 'success' && (
                  <motion.div 
                    className="bg-green-500/20 border border-green-500/30 rounded-lg p-4"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <p className="text-green-300 font-medium">✓ Message sent successfully!</p>
                    <p className="text-green-400 text-sm mt-1">We'll get back to you within 24 hours.</p>
                  </motion.div>
                )}

                {submitStatus === 'error' && (
                  <motion.div 
                    className="bg-red-500/20 border border-red-500/30 rounded-lg p-4"
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                  >
                    <p className="text-red-300 font-medium">✗ Failed to send message</p>
                    <p className="text-red-400 text-sm mt-1">Please try again or email us directly.</p>
                  </motion.div>
                )}

                <div className="flex items-center justify-between">
                  <p className="text-sm text-gray-400">
                    * Required fields
                  </p>
                  <motion.button
                    type="submit"
                    disabled={isSubmitting}
                    className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 disabled:from-gray-600 disabled:to-gray-600 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-cyan-500/25 disabled:transform-none disabled:shadow-none flex items-center space-x-2"
                    whileHover={{ scale: isSubmitting ? 1 : 1.05 }}
                    whileTap={{ scale: isSubmitting ? 1 : 0.95 }}
                  >
                    {isSubmitting ? (
                      <>
                        <div className="animate-spin rounded-full h-4 w-4 border-2 border-white border-t-transparent"></div>
                        <span>Sending...</span>
                      </>
                    ) : (
                      <>
                        <Send className="w-4 h-4" />
                        <span>Send Message</span>
                      </>
                    )}
                  </motion.button>
                </div>
              </form>
            </div>
          </motion.div>
        </div>

        {/* Additional Information */}
        <motion.div 
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6, delay: 0.4 }}
        >
          <div className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-xl p-8 backdrop-blur-sm">
            <h3 className="text-xl font-bold text-cyan-300 mb-4">Frequently Asked Questions</h3>
            <p className="text-gray-300 mb-4">
              Before reaching out, you might find answers to common questions in our comprehensive FAQ section.
            </p>
            <button className="bg-cyan-600/20 hover:bg-cyan-600/30 text-cyan-300 border border-cyan-500/30 hover:border-cyan-400/50 px-6 py-2 rounded-lg font-medium transition-all duration-300">
              Visit FAQ
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default Contact;