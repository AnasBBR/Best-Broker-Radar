import React from 'react';
import { motion } from 'framer-motion';
import { Target, Users, Shield, TrendingUp, Award, CheckCircle } from 'lucide-react';

const AboutUs = () => {
  const fadeInUp = {
    initial: { opacity: 0, y: 30 },
    animate: { opacity: 1, y: 0 },
    transition: { duration: 0.6 }
  };

  const staggerContainer = {
    animate: {
      transition: {
        staggerChildren: 0.2
      }
    }
  };

  const evaluationCriteria = [
    {
      icon: Shield,
      title: "Regulation & Safety",
      description: "We verify regulatory compliance with top-tier authorities like FCA, CySEC, and ASIC to ensure your funds are protected."
    },
    {
      icon: TrendingUp,
      title: "Trading Conditions",
      description: "We analyze spreads, leverage, execution speed, and trading costs to help you find the most competitive conditions."
    },
    {
      icon: Users,
      title: "User Experience",
      description: "Platform usability, customer support quality, and overall user satisfaction are key factors in our evaluation process."
    },
    {
      icon: Award,
      title: "Reputation & Trust",
      description: "We consider industry awards, user reviews, and years of operation to assess each broker's market reputation."
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Hero Section */}
        <motion.div 
          className="text-center mb-16"
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-6">
            About Best Broker Radar
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            Your trusted guide to finding the perfect trading platform in today's complex financial landscape.
          </p>
        </motion.div>

        {/* Mission Statement */}
        <motion.section 
          className="mb-16"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          <motion.div 
            className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-xl p-8 backdrop-blur-sm"
            variants={fadeInUp}
          >
            <div className="flex items-center mb-6">
              <Target className="w-8 h-8 text-cyan-400 mr-4" />
              <h2 className="text-2xl font-bold text-cyan-300">Our Mission</h2>
            </div>
            <p className="text-lg text-gray-300 leading-relaxed mb-4">
              At Best Broker Radar, we're dedicated to simplifying your search for reliable trading platforms. 
              Our mission is to provide transparent, comprehensive comparisons that empower traders to make 
              informed decisions about their financial future.
            </p>
            <p className="text-lg text-gray-300 leading-relaxed">
              We believe that every trader deserves access to trustworthy, well-regulated brokers that align 
              with their trading style, risk tolerance, and financial goals.
            </p>
          </motion.div>
        </motion.section>

        {/* How We Help */}
        <motion.section 
          className="mb-16"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          <motion.h2 
            className="text-3xl font-bold text-center bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-12"
            variants={fadeInUp}
          >
            How We Help You Find Reliable Trading Platforms
          </motion.h2>
          <div className="grid md:grid-cols-2 gap-8">
            {evaluationCriteria.map((criteria, index) => {
              const IconComponent = criteria.icon;
              return (
                <motion.div 
                  key={index}
                  className="bg-slate-800/30 border border-cyan-500/20 rounded-lg p-6 hover:border-cyan-400/40 transition-all duration-300 hover:shadow-lg hover:shadow-cyan-500/10"
                  variants={fadeInUp}
                >
                  <div className="flex items-start mb-4">
                    <div className="bg-cyan-500/20 p-3 rounded-lg mr-4">
                      <IconComponent className="w-6 h-6 text-cyan-400" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold text-cyan-300 mb-2">{criteria.title}</h3>
                    </div>
                  </div>
                  <p className="text-gray-300 leading-relaxed">{criteria.description}</p>
                </motion.div>
              );
            })}
          </div>
        </motion.section>

        {/* Evaluation Process */}
        <motion.section 
          className="mb-16"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          <motion.div 
            className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-xl p-8 backdrop-blur-sm"
            variants={fadeInUp}
          >
            <h2 className="text-2xl font-bold text-cyan-300 mb-6">Our Evaluation & Ranking Process</h2>
            <div className="space-y-4">
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-cyan-400 mr-3 mt-1 flex-shrink-0" />
                <p className="text-gray-300">
                  <strong className="text-cyan-300">Comprehensive Research:</strong> We conduct in-depth analysis of each broker's 
                  regulatory status, trading conditions, platform features, and customer feedback.
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-cyan-400 mr-3 mt-1 flex-shrink-0" />
                <p className="text-gray-300">
                  <strong className="text-cyan-300">Real Testing:</strong> Our team tests trading platforms, customer support, 
                  and withdrawal processes to provide authentic user experiences.
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-cyan-400 mr-3 mt-1 flex-shrink-0" />
                <p className="text-gray-300">
                  <strong className="text-cyan-300">Regular Updates:</strong> We continuously monitor broker performance and 
                  update our rankings to reflect current market conditions and regulatory changes.
                </p>
              </div>
              <div className="flex items-start">
                <CheckCircle className="w-5 h-5 text-cyan-400 mr-3 mt-1 flex-shrink-0" />
                <p className="text-gray-300">
                  <strong className="text-cyan-300">Unbiased Scoring:</strong> Our proprietary rating system evaluates brokers 
                  across multiple criteria to provide objective, comparable scores.
                </p>
              </div>
            </div>
          </motion.div>
        </motion.section>

        {/* Transparency Section */}
        <motion.section 
          className="mb-16"
          variants={staggerContainer}
          initial="initial"
          animate="animate"
        >
          <motion.div 
            className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-xl p-8 backdrop-blur-sm"
            variants={fadeInUp}
          >
            <h2 className="text-2xl font-bold text-cyan-300 mb-6">Transparency & Affiliate Partnerships</h2>
            <div className="space-y-4 text-gray-300">
              <p className="leading-relaxed">
                <strong className="text-cyan-300">Full Disclosure:</strong> We maintain complete transparency about our business model. 
                Best Broker Radar may earn commissions when you sign up with brokers through our affiliate links. 
                This helps us keep our comparison service free for all users.
              </p>
              <p className="leading-relaxed">
                <strong className="text-cyan-300">Editorial Independence:</strong> Our affiliate partnerships never influence our 
                rankings or reviews. We evaluate all brokers using the same rigorous criteria, regardless of 
                commission structures.
              </p>
              <p className="leading-relaxed">
                <strong className="text-cyan-300">Your Best Interest:</strong> Our recommendations are based solely on broker quality, 
                regulatory compliance, and suitability for different trading needs. We only partner with 
                reputable, well-regulated brokers.
              </p>
              <p className="leading-relaxed">
                <strong className="text-cyan-300">No Hidden Costs:</strong> Using our affiliate links never costs you extra. 
                In many cases, you may even receive exclusive bonuses or better terms through our partnerships.
              </p>
            </div>
          </motion.div>
        </motion.section>

        {/* Call to Action */}
        <motion.div 
          className="text-center bg-gradient-to-r from-cyan-500/10 to-purple-500/10 border border-cyan-500/20 rounded-xl p-8"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.8 }}
        >
          <h2 className="text-2xl font-bold text-cyan-300 mb-4">Ready to Find Your Perfect Broker?</h2>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Explore our comprehensive broker comparisons and find a trading platform that matches your needs, 
            backed by our commitment to transparency and quality.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <button className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white px-8 py-3 rounded-lg font-semibold transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-cyan-500/25">
              Compare Brokers
            </button>
            <button className="border border-cyan-500 text-cyan-300 hover:bg-cyan-500/10 px-8 py-3 rounded-lg font-semibold transition-all duration-300">
              View Top Rated
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

export default AboutUs;