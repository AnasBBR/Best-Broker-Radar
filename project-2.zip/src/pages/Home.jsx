import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { Radar, TrendingUp, Shield, Award, ArrowRight } from 'lucide-react';

const Home = () => {
  const featuredBrokers = [
    {
      id: 1,
      name: 'eToro',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=60&fit=crop&crop=center',
      rating: 4.5,
      minDeposit: '$200',
      regulation: 'CySEC, FCA, ASIC',
      bonus: 'Welcome bonus up to $1000'
    },
    {
      id: 2,
      name: 'Plus500',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=60&fit=crop&crop=center',
      rating: 4.2,
      minDeposit: '$100',
      regulation: 'CySEC, FCA, ASIC',
      bonus: 'Trading bonus up to $500'
    },
    {
      id: 3,
      name: 'XM Trading',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      rating: 4.3,
      minDeposit: '$5',
      regulation: 'CySEC, ASIC, IFSC',
      bonus: 'No deposit bonus $30'
    }
  ];

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Section */}
      <section className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <h1 className="text-4xl md:text-6xl font-bold mb-6">
                Find Your Perfect
                <span className="block text-yellow-400">Trading Broker</span>
              </h1>
              <p className="text-xl md:text-2xl mb-8 max-w-3xl mx-auto">
                Compare top-rated brokers, read reviews, and make informed trading decisions with our comprehensive broker analysis.
              </p>
              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Link
                  to="/compare"
                  className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 flex items-center justify-center gap-2"
                >
                  Compare Brokers
                  <ArrowRight className="w-5 h-5" />
                </Link>
                <Link
                  to="/brokers"
                  className="bg-transparent border-2 border-white hover:bg-white hover:text-blue-800 px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300"
                >
                  View All Brokers
                </Link>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Why Choose Best Broker Radar?
            </h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We provide comprehensive, unbiased broker comparisons to help you make the best trading decisions.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.1 }}
              className="text-center p-6 bg-white rounded-lg shadow-md"
            >
              <Shield className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Regulated Brokers</h3>
              <p className="text-gray-600">All featured brokers are properly regulated by top-tier financial authorities.</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
              className="text-center p-6 bg-white rounded-lg shadow-md"
            >
              <TrendingUp className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Detailed Analysis</h3>
              <p className="text-gray-600">In-depth reviews covering spreads, platforms, fees, and trading conditions.</p>
            </motion.div>
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.3 }}
              className="text-center p-6 bg-white rounded-lg shadow-md"
            >
              <Award className="w-12 h-12 text-blue-600 mx-auto mb-4" />
              <h3 className="text-xl font-semibold text-gray-800 mb-2">Unbiased Reviews</h3>
              <p className="text-gray-600">Honest, transparent reviews based on real trading experience and user feedback.</p>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Featured Brokers Section */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-800 mb-4">
              Top Rated Brokers
            </h2>
            <p className="text-lg text-gray-600">
              Start trading with these highly-rated, regulated brokers.
            </p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {featuredBrokers.map((broker, index) => (
              <motion.div
                key={broker.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6, delay: index * 0.1 }}
                className="bg-white border border-gray-200 rounded-lg shadow-md hover:shadow-lg transition-all duration-300 p-6"
              >
                <div className="text-center mb-4">
                  <img
                    src={broker.logo}
                    alt={`${broker.name} logo`}
                    className="w-20 h-12 object-contain mx-auto mb-2"
                  />
                  <h3 className="text-xl font-semibold text-gray-800">{broker.name}</h3>
                  <div className="flex justify-center items-center mt-2">
                    <span className="text-yellow-500 text-lg">★★★★★</span>
                    <span className="ml-2 text-gray-600">({broker.rating})</span>
                  </div>
                </div>
                <div className="space-y-2 mb-6">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Min Deposit:</span>
                    <span className="font-medium">{broker.minDeposit}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Regulation:</span>
                    <span className="font-medium text-sm">{broker.regulation}</span>
                  </div>
                  <div className="text-center text-sm text-green-600 font-medium">
                    {broker.bonus}
                  </div>
                </div>
                <button className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 rounded-lg font-semibold transition-all duration-300">
                  Trade Now
                </button>
              </motion.div>
            ))}
          </div>
          <div className="text-center mt-8">
            <Link
              to="/brokers"
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 px-8 py-3 rounded-lg font-medium transition-all duration-300 inline-flex items-center gap-2"
            >
              View All Brokers
              <ArrowRight className="w-4 h-4" />
            </Link>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-blue-600 text-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            Ready to Start Trading?
          </h2>
          <p className="text-xl mb-8">
            Compare brokers side-by-side and find the perfect match for your trading style.
          </p>
          <Link
            to="/compare"
            className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 inline-flex items-center gap-2"
          >
            Compare Brokers Now
            <ArrowRight className="w-5 h-5" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Home;