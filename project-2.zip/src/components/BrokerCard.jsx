import React from 'react';
import { ExternalLink, Star, Shield, CreditCard, TrendingUp } from 'lucide-react';

const BrokerCard = ({ broker }) => {
  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-4 h-4 ${
          i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'
        }`}
      />
    ));
  };

  return (
    <div className="bg-gradient-to-r from-slate-800/50 via-purple-900/30 to-slate-800/50 border border-cyan-500/30 rounded-lg shadow-2xl hover:shadow-cyan-500/20 transition-all duration-500 backdrop-blur-sm hover:border-cyan-400/50">
      <div className="p-6">
        <div className="flex flex-col lg:flex-row gap-6">
          {/* Logo and Basic Info */}
          <div className="lg:w-1/4 flex flex-col items-center lg:items-start">
            <div className="relative mb-4">
              <img
                src={broker.logo}
                alt={`${broker.name} logo`}
                className="w-24 h-16 object-contain rounded border border-cyan-500/30 bg-slate-800/50 p-2"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-400/10 to-purple-400/10 rounded"></div>
            </div>
            <h3 className="text-xl font-bold text-cyan-300 mb-2">{broker.name}</h3>
            <div className="flex items-center mb-4">
              {renderStars(broker.rating)}
              <span className="ml-2 text-sm text-gray-300">({broker.rating})</span>
            </div>
            <a
              href={broker.affiliateUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white px-6 py-3 rounded-lg font-medium transition-all duration-300 flex items-center gap-2 shadow-lg hover:shadow-cyan-500/30 transform hover:scale-105"
            >
              Trade Now
              <ExternalLink className="w-4 h-4" />
            </a>
          </div>

          {/* Detailed Information */}
          <div className="lg:w-3/4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="flex items-start gap-3">
                  <Shield className="w-5 h-5 text-green-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Regulation</h4>
                    <p className="text-gray-300 text-sm">{broker.regulation}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CreditCard className="w-5 h-5 text-blue-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Minimum Deposit</h4>
                    <p className="text-gray-300 text-sm">{broker.minDeposit}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <TrendingUp className="w-5 h-5 text-purple-400 mt-0.5 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Trading Platforms</h4>
                    <p className="text-gray-300 text-sm">{broker.platforms}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Available Assets</h4>
                  <p className="text-gray-300 text-sm">{broker.assets}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Spreads</h4>
                  <p className="text-gray-300 text-sm">{broker.spreads}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Leverage</h4>
                  <p className="text-gray-300 text-sm">{broker.leverage}</p>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Account Types</h4>
                  <p className="text-gray-300 text-sm">{broker.accountTypes}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Deposit Methods</h4>
                  <p className="text-gray-300 text-sm">{broker.depositMethods}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Withdrawal Methods</h4>
                  <p className="text-gray-300 text-sm">{broker.withdrawalMethods}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Bonus & Promotions</h4>
                  <p className="text-gray-300 text-sm">{broker.bonus}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Customer Support</h4>
                  <p className="text-gray-300 text-sm">{broker.support}</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrokerCard;