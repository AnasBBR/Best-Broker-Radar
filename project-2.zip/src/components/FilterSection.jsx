import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Filter, X, ChevronDown } from 'lucide-react';

const FilterSection = ({ onFilterChange, activeFilters, brokerCount }) => {
  const [showFilters, setShowFilters] = useState(false);
  const [expandedSections, setExpandedSections] = useState({});

  const filterOptions = {
    regulation: {
      label: 'Regulation',
      options: ['FCA', 'CySEC', 'ASIC', 'MAS', 'IFSC', 'FSA', 'CFTC', 'NFA']
    },
    minDeposit: {
      label: 'Minimum Deposit',
      options: ['$1-50', '$51-100', '$101-200', '$201-500', '$500+']
    },
    platforms: {
      label: 'Trading Platforms',
      options: ['MT4', 'MT5', 'WebTrader', 'Mobile App', 'cTrader', 'TradingView', 'Custom Platform']
    },
    assets: {
      label: 'Asset Types',
      options: ['Forex', 'Stocks', 'Crypto', 'Commodities', 'Indices', 'CFDs', 'ETFs', 'Options']
    },
    leverage: {
      label: 'Maximum Leverage',
      options: ['1:30', '1:50', '1:100', '1:200', '1:500', '1:1000+']
    },
    accountTypes: {
      label: 'Account Types',
      options: ['Standard', 'Premium', 'VIP', 'Islamic', 'Demo', 'Professional']
    }
  };

  const handleFilterChange = (category, value) => {
    onFilterChange(category, value);
  };

  const clearAllFilters = () => {
    onFilterChange('clear', null);
  };

  const clearCategoryFilter = (category) => {
    onFilterChange('clearCategory', category);
  };

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }));
  };

  const getActiveFilterCount = () => {
    return Object.values(activeFilters).reduce((total, filters) => total + filters.length, 0);
  };

  const activeFilterCount = getActiveFilterCount();

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-4">
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="flex items-center gap-2 bg-slate-800/50 hover:bg-slate-700/50 text-cyan-300 px-6 py-3 rounded-lg border border-cyan-500/30 transition-all duration-300 hover:border-cyan-400/50 hover:shadow-lg hover:shadow-cyan-500/20"
          >
            <Filter className="w-5 h-5" />
            <span className="font-medium">Filter Brokers</span>
            {activeFilterCount > 0 && (
              <span className="bg-cyan-500 text-white text-xs px-2 py-1 rounded-full">
                {activeFilterCount}
              </span>
            )}
            <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${showFilters ? 'rotate-180' : ''}`} />
          </button>
          
          {brokerCount !== undefined && (
            <div className="text-gray-300 text-sm">
              <span className="text-cyan-400 font-medium">{brokerCount}</span> brokers found
            </div>
          )}
        </div>
        
        {activeFilterCount > 0 && (
          <button
            onClick={clearAllFilters}
            className="flex items-center gap-2 text-gray-400 hover:text-cyan-300 text-sm transition-colors duration-300 px-3 py-2 rounded-lg hover:bg-slate-800/30"
          >
            <X className="w-4 h-4" />
            Clear All Filters
          </button>
        )}
      </div>

      {/* Active Filters Display */}
      {activeFilterCount > 0 && (
        <div className="mb-4">
          <div className="flex flex-wrap gap-2">
            {Object.entries(activeFilters).map(([category, filters]) =>
              filters.map((filter) => (
                <span
                  key={`${category}-${filter}`}
                  className="inline-flex items-center gap-2 bg-cyan-500/20 text-cyan-300 px-3 py-1 rounded-full text-sm border border-cyan-500/30"
                >
                  <span className="text-xs text-cyan-400 uppercase">
                    {filterOptions[category]?.label || category}:
                  </span>
                  {filter}
                  <button
                    onClick={() => handleFilterChange(category, filter)}
                    className="hover:text-cyan-200 transition-colors duration-200"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </span>
              ))
            )}
          </div>
        </div>
      )}

      <motion.div
        initial={{ height: 0, opacity: 0 }}
        animate={{ 
          height: showFilters ? 'auto' : 0, 
          opacity: showFilters ? 1 : 0 
        }}
        transition={{ duration: 0.4, ease: 'easeInOut' }}
        className="overflow-hidden"
      >
        <div className="bg-gradient-to-r from-slate-800/30 via-purple-900/20 to-slate-800/30 border border-cyan-500/20 rounded-lg backdrop-blur-sm">
          <div className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Object.entries(filterOptions).map(([category, { label, options }]) => {
                const isExpanded = expandedSections[category] !== false;
                const categoryFilters = activeFilters[category] || [];
                
                return (
                  <div key={category} className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-cyan-300 flex items-center gap-2">
                        {label}
                        {categoryFilters.length > 0 && (
                          <span className="bg-cyan-500 text-white text-xs px-2 py-0.5 rounded-full">
                            {categoryFilters.length}
                          </span>
                        )}
                      </h4>
                      <div className="flex items-center gap-2">
                        {categoryFilters.length > 0 && (
                          <button
                            onClick={() => clearCategoryFilter(category)}
                            className="text-gray-400 hover:text-cyan-300 text-xs transition-colors duration-200"
                            title="Clear category filters"
                          >
                            <X className="w-3 h-3" />
                          </button>
                        )}
                        <button
                          onClick={() => toggleSection(category)}
                          className="text-gray-400 hover:text-cyan-300 transition-colors duration-200"
                        >
                          <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isExpanded ? 'rotate-180' : ''}`} />
                        </button>
                      </div>
                    </div>
                    
                    <motion.div
                      initial={false}
                      animate={{ height: isExpanded ? 'auto' : 0, opacity: isExpanded ? 1 : 0 }}
                      transition={{ duration: 0.2 }}
                      className="overflow-hidden"
                    >
                      <div className="space-y-2 max-h-40 overflow-y-auto scrollbar-hide">
                        {options.map((option) => {
                          const isChecked = categoryFilters.includes(option);
                          return (
                            <label key={option} className="flex items-center gap-3 cursor-pointer group hover:bg-slate-700/20 p-2 rounded transition-colors duration-200">
                              <div className="relative">
                                <input
                                  type="checkbox"
                                  checked={isChecked}
                                  onChange={() => handleFilterChange(category, option)}
                                  className="sr-only"
                                />
                                <div className={`w-4 h-4 border-2 rounded transition-all duration-200 ${
                                  isChecked 
                                    ? 'bg-cyan-500 border-cyan-500' 
                                    : 'border-cyan-500/50 hover:border-cyan-400'
                                }`}>
                                  {isChecked && (
                                    <motion.div
                                      initial={{ scale: 0 }}
                                      animate={{ scale: 1 }}
                                      className="w-full h-full flex items-center justify-center"
                                    >
                                      <svg className="w-2.5 h-2.5 text-white" fill="currentColor" viewBox="0 0 20 20">
                                        <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                                      </svg>
                                    </motion.div>
                                  )}
                                </div>
                              </div>
                              <span className={`text-sm transition-colors duration-200 ${
                                isChecked ? 'text-cyan-300 font-medium' : 'text-gray-300 group-hover:text-cyan-400'
                              }`}>
                                {option}
                              </span>
                            </label>
                          );
                        })}
                      </div>
                    </motion.div>
                  </div>
                );
              })}
            </div>
            
            <div className="mt-6 pt-4 border-t border-cyan-500/20 flex justify-between items-center">
              <div className="text-sm text-gray-400">
                Use filters to narrow down brokers based on your preferences
              </div>
              <div className="flex gap-3">
                <button
                  onClick={clearAllFilters}
                  className="text-sm text-gray-400 hover:text-cyan-300 transition-colors duration-200"
                >
                  Reset All
                </button>
                <button
                  onClick={() => setShowFilters(false)}
                  className="bg-cyan-600 hover:bg-cyan-500 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300"
                >
                  Apply Filters
                </button>
              </div>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

export default FilterSection;