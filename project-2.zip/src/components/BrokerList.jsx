
import React, { useState, useMemo } from 'react';
import { motion } from 'framer-motion';
import BrokerCard from './BrokerCard';
import FilterSection from './FilterSection';

const BrokerList = () => {
  const [activeTab, setActiveTab] = useState('all');
  const [activeFilters, setActiveFilters] = useState({
    regulation: [],
    minDeposit: [],
    platforms: [],
    assets: [],
    leverage: [],
    accountTypes: []
  });

  const brokers = [
    {
      id: 1,
      name: 'Exness',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, FCA, FSCA',
      minDeposit: '$1',
      platforms: 'MT4, MT5, Exness Terminal',
      assets: 'Forex, Metals, Energies, Indices',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:2000',
      accountTypes: 'Standard, Pro, Zero, Raw Spread',
      depositMethods: 'Credit Card, Skrill, Neteller, Bank Transfer',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus available',
      support: '24/7 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/exness',
      rating: 4.6,
      category: ['forex', 'metals']
    },
    {
      id: 2,
      name: 'FBS',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, IFSC, ASIC',
      minDeposit: '$1',
      platforms: 'MT4, MT5, FBS Trader',
      assets: 'Forex, Stocks, Metals, Energies',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:3000',
      accountTypes: 'Cent, Micro, Standard, Zero Spread, ECN',
      depositMethods: 'Credit Card, Skrill, Neteller, Perfect Money',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $140',
      support: '24/7 Live Chat, Phone',
      affiliateUrl: 'https://your-affiliate-link.com/fbs',
      rating: 4.4,
      category: ['forex', 'stocks']
    },
    {
      id: 3,
      name: 'AvaTrade',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      regulation: 'CBI, ASIC, FSA, FFAJ',
      minDeposit: '$100',
      platforms: 'MT4, MT5, AvaTradeGO, WebTrader',
      assets: 'Forex, Stocks, Indices, Commodities, Crypto',
      spreads: 'From 0.9 pips',
      leverage: 'Up to 1:400',
      accountTypes: 'Standard, Professional, Islamic',
      depositMethods: 'Credit Card, Bank Transfer, Skrill, Neteller',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $10,000',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/avatrade',
      rating: 4.3,
      category: ['forex', 'crypto', 'stocks']
    },
    {
      id: 4,
      name: 'Vantage Markets',
      logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=100&h=60&fit=crop&crop=center',
      regulation: 'ASIC, CIMA, VFSC',
      minDeposit: '$200',
      platforms: 'MT4, MT5, Vantage App',
      assets: 'Forex, Indices, Commodities, Shares',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard STP, Raw ECN, Pro ECN',
      depositMethods: 'Credit Card, Bank Transfer, Skrill, Neteller',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Deposit bonus up to $1000',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/vantage',
      rating: 4.2,
      category: ['forex', 'stocks']
    },
    {
      id: 5,
      name: 'Eightcap',
      logo: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=100&h=60&fit=crop&crop=center',
      regulation: 'ASIC, SCB',
      minDeposit: '$100',
      platforms: 'MT4, MT5, TradingView',
      assets: 'Forex, Indices, Commodities, Crypto, Shares',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, Raw',
      depositMethods: 'Credit Card, Bank Transfer, PayPal, Skrill',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/eightcap',
      rating: 4.1,
      category: ['forex', 'crypto']
    },
    {
      id: 6,
      name: 'XTB',
      logo: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=100&h=60&fit=crop&crop=center',
      regulation: 'FCA, CySEC, KNF, IFSC',
      minDeposit: '$1',
      platforms: 'xStation 5, MT4',
      assets: 'Forex, Indices, Commodities, Stocks, ETFs',
      spreads: 'From 0.1 pips',
      leverage: 'Up to 1:30',
      accountTypes: 'Standard, Pro',
      depositMethods: 'Credit Card, Bank Transfer, Skrill, PayPal',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/xtb',
      rating: 4.5,
      category: ['forex', 'stocks']
    },
    {
      id: 7,
      name: 'FXTM',
      logo: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, FCA, IFSC',
      minDeposit: '$10',
      platforms: 'MT4, MT5, FXTM Trader',
      assets: 'Forex, Stocks, Indices, Commodities',
      spreads: 'From 1.3 pips',
      leverage: 'Up to 1:1000',
      accountTypes: 'Standard, Cent, ECN, ECN Zero',
      depositMethods: 'Credit Card, Skrill, Neteller, Bank Transfer',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $2000',
      support: '24/5 Multilingual Support',
      affiliateUrl: 'https://your-affiliate-link.com/fxtm',
      rating: 4.1,
      category: ['forex', 'stocks']
    },
    {
      id: 8,
      name: 'Plus500',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, FCA, ASIC, MAS',
      minDeposit: '$100',
      platforms: 'Plus500 WebTrader, Mobile App',
      assets: 'CFDs, Forex, Stocks, Indices',
      spreads: 'Tight spreads from 0.6 pips',
      leverage: 'Up to 1:30',
      accountTypes: 'Standard Account',
      depositMethods: 'Credit Card, PayPal, Skrill',
      withdrawalMethods: 'Credit Card, Bank Transfer',
      bonus: 'Trading bonus up to $500',
      support: '24/7 Email Support',
      affiliateUrl: 'https://your-affiliate-link.com/plus500',
      rating: 4.2,
      category: ['forex', 'stocks', 'cfds']
    },
    {
      id: 9,
      name: 'eToro',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, FCA, ASIC',
      minDeposit: '$200',
      platforms: 'eToro Platform, Mobile App',
      assets: 'Stocks, Crypto, Forex, Commodities',
      spreads: 'From 1 pip',
      leverage: 'Up to 1:30',
      accountTypes: 'Standard, Professional',
      depositMethods: 'Credit Card, PayPal, Bank Transfer',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $1000',
      support: '24/7 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/etoro',
      rating: 4.5,
      category: ['stocks', 'crypto', 'forex']
    },
    {
      id: 10,
      name: 'FxPro',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, FCA, DFSA, SCB',
      minDeposit: '$100',
      platforms: 'MT4, MT5, cTrader, FxPro Edge',
      assets: 'Forex, Indices, Commodities, Shares, Futures',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'MT4 Instant, MT5, cTrader, Edge',
      depositMethods: 'Credit Card, Bank Transfer, Skrill, Neteller',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/fxpro',
      rating: 4.3,
      category: ['forex', 'stocks']
    },
    {
      id: 11,
      name: 'XM Group',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, ASIC, IFSC',
      minDeposit: '$5',
      platforms: 'MT4, MT5, XM WebTrader',
      assets: 'Forex, Stocks, Indices, Commodities',
      spreads: 'From 0.1 pips',
      leverage: 'Up to 1:888',
      accountTypes: 'Micro, Standard, XM Zero',
      depositMethods: 'Credit Card, Neteller, Skrill',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus $30',
      support: '24/5 Live Chat, Phone',
      affiliateUrl: 'https://your-affiliate-link.com/xm',
      rating: 4.3,
      category: ['forex', 'stocks']
    },
    {
      id: 12,
      name: 'Admiral Markets',
      logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=100&h=60&fit=crop&crop=center',
      regulation: 'FCA, CySEC, ASIC, EFSA',
      minDeposit: '$100',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Stocks, Indices, Commodities, ETFs',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Trade.MT4, Trade.MT5, Zero.MT4',
      depositMethods: 'Credit Card, Bank Transfer, Skrill, Neteller',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/admiralmarkets',
      rating: 4.4,
      category: ['forex', 'stocks']
    },
    {
      id: 13,
      name: 'BlackBull Markets',
      logo: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=100&h=60&fit=crop&crop=center',
      regulation: 'FMA, FSA',
      minDeposit: '$200',
      platforms: 'MT4, MT5, TradingView, CopyTrader',
      assets: 'Forex, Indices, Commodities, Crypto, Shares',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, Prime, Institutional',
      depositMethods: 'Credit Card, Bank Transfer, Crypto',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/blackbull',
      rating: 4.2,
      category: ['forex', 'crypto']
    },
    {
      id: 14,
      name: 'RoboForex',
      logo: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC, IFSC',
      minDeposit: '$10',
      platforms: 'MT4, MT5, cTrader, R WebTrader',
      assets: 'Forex, Stocks, Indices, Commodities, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:2000',
      accountTypes: 'Prime, ECN, Pro, R StocksTrader',
      depositMethods: 'Credit Card, Bank Transfer, Crypto, E-wallets',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to 120%',
      support: '24/7 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/roboforex',
      rating: 4.0,
      category: ['forex', 'crypto', 'stocks']
    },
    {
      id: 15,
      name: 'Moneta Markets',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=60&fit=crop&crop=center',
      regulation: 'VFSC',
      minDeposit: '$50',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Indices, Commodities, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:1000',
      accountTypes: 'Standard, Raw, Islamic',
      depositMethods: 'Credit Card, Bank Transfer, Crypto',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $5000',
      support: '24/5 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/moneta',
      rating: 3.9,
      category: ['forex', 'crypto']
    },
    {
      id: 16,
      name: 'AdroFX',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=60&fit=crop&crop=center',
      regulation: 'VFSC',
      minDeposit: '$25',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Indices, Commodities, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, Pro, VIP',
      depositMethods: 'Credit Card, Bank Transfer, E-wallets',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to 100%',
      support: '24/5 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/adrofx',
      rating: 3.8,
      category: ['forex', 'crypto']
    },
    {
      id: 17,
      name: 'TradeNation',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      regulation: 'FCA, SCB',
      minDeposit: '$1',
      platforms: 'MT4, WebTrader, Mobile App',
      assets: 'Forex, Indices, Commodities, Shares',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, Pro',
      depositMethods: 'Credit Card, Bank Transfer, E-wallets',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/tradenation',
      rating: 4.1,
      category: ['forex', 'stocks']
    },
    {
      id: 18,
      name: 'Switch Markets',
      logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=100&h=60&fit=crop&crop=center',
      regulation: 'VFSC',
      minDeposit: '$100',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Indices, Commodities, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, ECN, VIP',
      depositMethods: 'Credit Card, Bank Transfer, Crypto',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $10000',
      support: '24/5 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/switchmarkets',
      rating: 3.9,
      category: ['forex', 'crypto']
    },
    {
      id: 19,
      name: 'PrimeXBT',
      logo: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=100&h=60&fit=crop&crop=center',
      regulation: 'Unregulated',
      minDeposit: '$1',
      platforms: 'PrimeXBT Platform, Mobile App',
      assets: 'Crypto, Forex, Indices, Commodities',
      spreads: 'Variable spreads',
      leverage: 'Up to 1:1000',
      accountTypes: 'Standard',
      depositMethods: 'Bitcoin, Ethereum, USDT',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Trading bonus up to 50%',
      support: '24/7 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/primexbt',
      rating: 4.0,
      category: ['crypto', 'forex']
    },
    {
      id: 20,
      name: 'NordFX',
      logo: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=100&h=60&fit=crop&crop=center',
      regulation: 'VFSC',
      minDeposit: '$10',
      platforms: 'MT4, WebTrader',
      assets: 'Forex, Metals, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:1000',
      accountTypes: 'Fix, Pro, Crypto, PAMM',
      depositMethods: 'Credit Card, Bank Transfer, Crypto, E-wallets',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $30',
      support: '24/5 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/nordfx',
      rating: 3.8,
      category: ['forex', 'crypto']
    },
    {
      id: 21,
      name: 'City Index',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=60&fit=crop&crop=center',
      regulation: 'FCA, ASIC, JSC',
      minDeposit: '$250',
      platforms: 'AT Pro, WebTrader, Mobile App',
      assets: 'Forex, Indices, Commodities, Shares',
      spreads: 'From 0.5 pips',
      leverage: 'Up to 1:200',
      accountTypes: 'Spread Betting, CFD Trading',
      depositMethods: 'Credit Card, Bank Transfer',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/cityindex',
      rating: 4.1,
      category: ['forex', 'stocks']
    },
    {
      id: 22,
      name: 'VT Markets',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=60&fit=crop&crop=center',
      regulation: 'ASIC, CIMA, VFSC',
      minDeposit: '$200',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Indices, Commodities, Shares',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard STP, Raw ECN',
      depositMethods: 'Credit Card, Bank Transfer, Skrill, Neteller',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $500',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/vtmarkets',
      rating: 4.0,
      category: ['forex', 'stocks']
    },
    {
      id: 23,
      name: 'Hantec Markets',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      regulation: 'FCA, SFC',
      minDeposit: '$1000',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Indices, Commodities, Metals',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:400',
      accountTypes: 'Standard, Premium, VIP',
      depositMethods: 'Credit Card, Bank Transfer',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/hantec',
      rating: 4.2,
      category: ['forex']
    },
    {
      id: 24,
      name: 'Alpari',
      logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=100&h=60&fit=crop&crop=center',
      regulation: 'FSC, CRFIN',
      minDeposit: '$1',
      platforms: 'MT4, MT5, Alpari Mobile',
      assets: 'Forex, Metals, Indices, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:1000',
      accountTypes: 'Standard, ECN, Pro',
      depositMethods: 'Credit Card, Bank Transfer, E-wallets',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to 100%',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/alpari',
      rating: 4.0,
      category: ['forex', 'crypto']
    },
    {
      id: 25,
      name: 'Orbex',
      logo: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?w=100&h=60&fit=crop&crop=center',
      regulation: 'CySEC',
      minDeposit: '$100',
      platforms: 'MT4, WebTrader, Mobile App',
      assets: 'Forex, Indices, Commodities, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, Premium, VIP',
      depositMethods: 'Credit Card, Bank Transfer, E-wallets',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to 50%',
      support: '24/5 Live Chat, Phone, Email',
      affiliateUrl: 'https://your-affiliate-link.com/orbex',
      rating: 3.9,
      category: ['forex', 'crypto']
    },
    {
      id: 26,
      name: 'Traders Union',
      logo: 'https://images.unsplash.com/photo-1590283603385-17ffb3a7f29f?w=100&h=60&fit=crop&crop=center',
      regulation: 'Various Partners',
      minDeposit: 'Varies by broker',
      platforms: 'Multiple platforms via partners',
      assets: 'Forex, Stocks, Crypto, Commodities',
      spreads: 'Varies by broker',
      leverage: 'Varies by broker',
      accountTypes: 'Multiple types available',
      depositMethods: 'Varies by broker partner',
      withdrawalMethods: 'Varies by broker partner',
      bonus: 'Various bonuses available',
      support: '24/7 Community Support',
      affiliateUrl: 'https://your-affiliate-link.com/tradersunion',
      rating: 4.1,
      category: ['forex', 'stocks', 'crypto']
    },
    {
      id: 27,
      name: 'Forex Mentor',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=100&h=60&fit=crop&crop=center',
      regulation: 'Educational Service',
      minDeposit: 'N/A - Education Only',
      platforms: 'Educational Platform',
      assets: 'Forex Education & Signals',
      spreads: 'N/A',
      leverage: 'N/A',
      accountTypes: 'Basic, Premium, VIP Education',
      depositMethods: 'Credit Card, PayPal',
      withdrawalMethods: 'N/A',
      bonus: 'Free trial available',
      support: '24/5 Educational Support',
      affiliateUrl: 'https://your-affiliate-link.com/forexmentor',
      rating: 4.3,
      category: ['forex']
    },
    {
      id: 28,
      name: 'Capitalist Exploits',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=60&fit=crop&crop=center',
      regulation: 'Investment Research',
      minDeposit: 'N/A - Research Service',
      platforms: 'Research Platform',
      assets: 'Investment Research & Analysis',
      spreads: 'N/A',
      leverage: 'N/A',
      accountTypes: 'Insider, Professional',
      depositMethods: 'Credit Card, Bank Transfer',
      withdrawalMethods: 'N/A',
      bonus: 'Free reports available',
      support: 'Email Support',
      affiliateUrl: 'https://your-affiliate-link.com/capitalistexploits',
      rating: 4.0,
      category: ['stocks']
    },
    {
      id: 29,
      name: 'FXView',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=100&h=60&fit=crop&crop=center',
      regulation: 'VFSC',
      minDeposit: '$10',
      platforms: 'MT4, MT5, WebTrader',
      assets: 'Forex, Indices, Commodities, Crypto',
      spreads: 'From 0.0 pips',
      leverage: 'Up to 1:500',
      accountTypes: 'Standard, ECN, Islamic',
      depositMethods: 'Credit Card, Bank Transfer, Crypto',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $2000',
      support: '24/5 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/fxview',
      rating: 3.8,
      category: ['forex', 'crypto']
    },
    {
      id: 30,
      name: 'ExpertOption',
      logo: 'https://images.unsplash.com/photo-1559526324-4b87b5e36e44?w=100&h=60&fit=crop&crop=center',
      regulation: 'VFSC, FMRRC',
      minDeposit: '$10',
      platforms: 'ExpertOption Platform, Mobile App',
      assets: 'Binary Options, Forex, Crypto, Stocks',
      spreads: 'Fixed payouts up to 95%',
      leverage: 'N/A for Binary Options',
      accountTypes: 'Basic, Silver, Gold, Platinum',
      depositMethods: 'Credit Card, E-wallets, Crypto',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to 100%',
      support: '24/7 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/expertoption',
      rating: 3.7,
      category: ['forex', 'crypto', 'stocks']
    }
  ];

  const tabs = [
    { id: 'all', label: 'All Brokers' },
    { id: 'forex', label: 'Forex' },
    { id: 'stocks', label: 'Stocks' },
    { id: 'crypto', label: 'Crypto' },
    { id: 'cfds', label: 'CFDs' }
  ];

  // Filter brokers based on active filters and tabs
  const filteredBrokers = useMemo(() => {
    let filtered = brokers;

    // Filter by tab
    if (activeTab !== 'all') {
      filtered = filtered.filter(broker =>
        broker.category.includes(activeTab)
      );
    }

    // Filter by active filters
    Object.entries(activeFilters).forEach(([filterType, filterValues]) => {
      if (filterValues.length > 0) {
        filtered = filtered.filter(broker => {
          switch (filterType) {
            case 'regulation':
              return filterValues.some(value =>
                broker.regulation.includes(value)
              );
            case 'minDeposit':
              const brokerDeposit = parseInt(broker.minDeposit.replace(/[^0-9]/g, ''));
              return filterValues.some(range => {
                if (range === '$1-50') return brokerDeposit >= 1 && brokerDeposit <= 50;
                if (range === '$51-100') return brokerDeposit >= 51 && brokerDeposit <= 100;
                if (range === '$101-200') return brokerDeposit >= 101 && brokerDeposit <= 200;
                if (range === '$201-500') return brokerDeposit >= 201 && brokerDeposit <= 500;
                if (range === '$500+') return brokerDeposit > 500;
                return false;
              });
            case 'platforms':
              return filterValues.some(value =>
                broker.platforms.toLowerCase().includes(value.toLowerCase())
              );
            case 'assets':
              return filterValues.some(value =>
                broker.assets.toLowerCase().includes(value.toLowerCase())
              );
            case 'leverage':
              const brokerLeverage = broker.leverage.match(/1:(\d+)/)?.[1];
              if (!brokerLeverage) return false;
              const brokerLeverageNum = parseInt(brokerLeverage);
              return filterValues.some(range => {
                const rangeNum = parseInt(range.replace('1:', '').replace('+', ''));
                if (range.includes('+')) return brokerLeverageNum >= rangeNum;
                return brokerLeverageNum <= rangeNum;
              });
            case 'accountTypes':
              return filterValues.some(value =>
                broker.accountTypes.toLowerCase().includes(value.toLowerCase())
              );
            default:
              return true;
          }
        });
      }
    });

    return filtered;
  }, [activeTab, activeFilters]);

  const handleFilterChange = (category, value) => {
    if (category === 'clear') {
      setActiveFilters({
        regulation: [],
        minDeposit: [],
        platforms: [],
        assets: [],
        leverage: [],
        accountTypes: []
      });
      return;
    }

    if (category === 'clearCategory') {
      setActiveFilters(prev => ({
        ...prev,
        [value]: []
      }));
      return;
    }

    setActiveFilters(prev => {
      const currentFilters = prev[category] || [];
      const isActive = currentFilters.includes(value);

      return {
        ...prev,
        [category]: isActive
          ? currentFilters.filter(item => item !== value)
          : [...currentFilters, value]
      };
    });
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center mb-12">
          <h1 className="text-3xl md:text-4xl font-bold bg-gradient-to-r from-cyan-400 via-purple-400 to-cyan-400 bg-clip-text text-transparent mb-4">
            Advanced Broker Detection System
          </h1>
          <p className="text-lg text-gray-300 max-w-3xl mx-auto">
            Scan and analyze top trading brokers with our quantum-powered comparison matrix.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap justify-center mb-8 border-b border-cyan-500/30">
          {tabs.map((tab) => {
            const tabBrokerCount = tab.id === 'all'
              ? brokers.length
              : brokers.filter(broker => broker.category.includes(tab.id)).length;

            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`px-6 py-3 font-medium text-sm transition-all duration-300 relative ${
                  activeTab === tab.id
                    ? 'text-cyan-400 border-b-2 border-cyan-400 shadow-lg shadow-cyan-400/20'
                    : 'text-gray-400 hover:text-cyan-300'
                }`}
              >
                <span>{tab.label}</span>
                <span className="ml-2 text-xs opacity-70">({tabBrokerCount})</span>
                {activeTab === tab.id && (
                  <motion.div
                    layoutId="activeTab"
                    className="absolute inset-0 bg-cyan-400/10 rounded-t-lg"
                    initial={false}
                    transition={{ type: "spring", stiffness: 500, damping: 30 }}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Filter Section */}
        <FilterSection
          onFilterChange={handleFilterChange}
          activeFilters={activeFilters}
          brokerCount={filteredBrokers.length}
        />

        {/* Results Summary */}
        <div className="mb-6">
          <div className="flex items-center justify-between">
            <div className="text-gray-300">
              {filteredBrokers.length === 0 ? (
                <span className="text-red-400">No brokers match your current filters</span>
              ) : (
                <span>
                  Showing <span className="text-cyan-400 font-medium">{filteredBrokers.length}</span> of{' '}
                  <span className="text-cyan-400 font-medium">{brokers.length}</span> brokers
                </span>
              )}
            </div>
            {filteredBrokers.length > 0 && (
              <div className="text-sm text-gray-400">
                Sorted by rating (highest first)
              </div>
            )}
          </div>
        </div>

        {/* Broker List */}
        {filteredBrokers.length === 0 ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-center py-16"
          >
            <div className="bg-slate-800/30 border border-cyan-500/20 rounded-lg p-8 max-w-md mx-auto">
              <div className="text-6xl mb-4">🔍</div>
              <h3 className="text-xl font-semibold text-cyan-300 mb-2">No Results Found</h3>
              <p className="text-gray-400 mb-4">
                Try adjusting your filters or browse all brokers to find the perfect match.
              </p>
              <button
                onClick={() => handleFilterChange('clear', null)}
                className="bg-cyan-600 hover:bg-cyan-500 text-white px-6 py-2 rounded-lg font-medium transition-all duration-300"
              >
                Clear All Filters
              </button>
            </div>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="space-y-6"
          >
            {filteredBrokers
              .sort((a, b) => b.rating - a.rating)
              .map((broker, index) => (
                <motion.div
                  key={broker.id}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.3, delay: index * 0.1 }}
                  layout
                >
                  <BrokerCard broker={broker} />
                </motion.div>
              ))
            }
          </motion.div>
        )}

        {/* Load More / Pagination could be added here */}
        {filteredBrokers.length > 0 && (
          <div className="text-center mt-12">
            <div className="text-gray-400 text-sm">
              End of results. Want to see more brokers?{' '}
              <button
                onClick={() => handleFilterChange('clear', null)}
                className="text-cyan-400 hover:text-cyan-300 underline transition-colors duration-200"
              >
                Clear filters
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default BrokerList;
