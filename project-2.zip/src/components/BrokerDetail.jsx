import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft, ExternalLink, Star, Shield, CreditCard, TrendingUp, Award, Phone, Mail } from 'lucide-react';

const BrokerDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();

  // Extended broker data with more brokers
  const brokers = {
    1: {
      name: 'eToro',
      logo: 'https://images.unsplash.com/photo-1611974789855-9c2a0a7236a3?w=200&h=120&fit=crop&crop=center',
      regulation: 'CySEC, FCA, ASIC',
      minDeposit: '$200',
      platforms: 'eToro Platform, Mobile App',
      assets: 'Stocks, Crypto, Forex, Commodities',
      spreads: 'From 1 pip',
      leverage: 'Up to 1:30',
      accountTypes: 'Standard, Professional',
      depositMethods: 'Credit Card, PayPal, Bank Transfer',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'Welcome bonus up to $1000',
      support: '24/7 Live Chat, Email',
      affiliateUrl: 'https://your-affiliate-link.com/etoro',
      rating: 4.5,
      description: 'eToro is a leading social trading platform that allows users to copy successful traders and invest in a wide range of assets including stocks, cryptocurrencies, and forex.',
      pros: ['Social trading features', 'User-friendly interface', 'Wide range of assets', 'Copy trading functionality'],
      cons: ['Limited research tools', 'Withdrawal fees', 'Not available in all countries']
    },
    2: {
      name: 'Plus500',
      logo: 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=200&h=120&fit=crop&crop=center',
      regulation: 'CySEC, FCA, ASIC, MAS',
      minDeposit: '$100',
      platforms: 'Plus500 WebTrader, Mobile App',
      assets: 'CFDs, Forex, Stocks, Indices',
      spreads: 'Tight spreads from 0.6 pips',
      leverage: 'Up to 1:30',
      accountTypes: 'Standard Account',
      depositMethods: 'Credit Card, PayPal, Skrill',
      withdrawalMethods: 'Credit Card, Bank Transfer',
      bonus: 'Trading bonus up to $500',
      support: '24/7 Email Support',
      affiliateUrl: 'https://your-affiliate-link.com/plus500',
      rating: 4.2,
      description: 'Plus500 is a well-established CFD broker offering a simple and intuitive trading platform with competitive spreads and a wide range of instruments.',
      pros: ['Simple platform', 'Competitive spreads', 'Strong regulation', 'No commission trading'],
      cons: ['Limited educational resources', 'No MT4/MT5', 'Inactivity fees']
    },
    3: {
      name: 'XM Trading',
      logo: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?w=200&h=120&fit=crop&crop=center',
      regulation: 'CySEC, ASIC, IFSC',
      minDeposit: '$5',
      platforms: 'MT4, MT5, XM WebTrader',
      assets: 'Forex, Stocks, Indices, Commodities',
      spreads: 'From 0.1 pips',
      leverage: 'Up to 1:888',
      accountTypes: 'Micro, Standard, XM Zero',
      depositMethods: 'Credit Card, Neteller, Skrill',
      withdrawalMethods: 'Same as deposit methods',
      bonus: 'No deposit bonus $30',
      support: '24/5 Live Chat, Phone',
      affiliateUrl: 'https://your-affiliate-link.com/xm',
      rating: 4.3,
      description: 'XM Trading offers comprehensive trading solutions with MetaTrader platforms, competitive spreads, and excellent customer support for traders of all levels.',
      pros: ['Low minimum deposit', 'MT4/MT5 platforms', 'Good customer support', 'Multiple account types'],
      cons: ['High leverage risk', 'Limited stock selection', 'Withdrawal processing time']
    }
  };

  const broker = brokers[id];

  if (!broker) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-cyan-300 mb-4">Broker Not Found</h2>
          <button
            onClick={() => navigate('/')}
            className="bg-gradient-to-r from-cyan-600 to-purple-600 text-white px-6 py-3 rounded-lg font-medium transition-all duration-300 hover:shadow-cyan-500/30"
          >
            Back to Brokers
          </button>
        </div>
      </div>
    );
  }

  const renderStars = (rating) => {
    return Array.from({ length: 5 }, (_, i) => (
      <Star
        key={i}
        className={`w-5 h-5 ${
          i < Math.floor(rating) ? 'text-yellow-400 fill-current' : 'text-gray-600'
        }`}
      />
    ));
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <button
          onClick={() => navigate('/')}
          className="flex items-center gap-2 text-cyan-300 hover:text-cyan-200 mb-8 transition-colors duration-300"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Brokers
        </button>

        <div className="bg-gradient-to-r from-slate-800/50 via-purple-900/30 to-slate-800/50 border border-cyan-500/30 rounded-lg shadow-2xl backdrop-blur-sm">
          {/* Header Section */}
          <div className="p-8 border-b border-cyan-500/20">
            <div className="flex flex-col lg:flex-row items-start lg:items-center gap-6">
              <div className="flex items-center gap-6">
                <img
                  src={broker.logo}
                  alt={`${broker.name} logo`}
                  className="w-32 h-20 object-contain rounded border border-cyan-500/30 bg-slate-800/50 p-3"
                />
                <div>
                  <h1 className="text-3xl font-bold text-cyan-300 mb-2">{broker.name}</h1>
                  <div className="flex items-center mb-3">
                    {renderStars(broker.rating)}
                    <span className="ml-2 text-lg text-gray-300">({broker.rating})</span>
                  </div>
                  <p className="text-gray-300 max-w-2xl">{broker.description}</p>
                </div>
              </div>
              <div className="lg:ml-auto">
                <a
                  href={broker.affiliateUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all duration-300 flex items-center gap-3 shadow-lg hover:shadow-cyan-500/30 transform hover:scale-105"
                >
                  Start Trading
                  <ExternalLink className="w-5 h-5" />
                </a>
              </div>
            </div>
          </div>

          {/* Details Section */}
          <div className="p-8">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-cyan-300 mb-4">Trading Information</h3>
                
                <div className="flex items-start gap-3">
                  <Shield className="w-6 h-6 text-green-400 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Regulation</h4>
                    <p className="text-gray-300">{broker.regulation}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <CreditCard className="w-6 h-6 text-blue-400 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Minimum Deposit</h4>
                    <p className="text-gray-300">{broker.minDeposit}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <TrendingUp className="w-6 h-6 text-purple-400 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Trading Platforms</h4>
                    <p className="text-gray-300">{broker.platforms}</p>
                  </div>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Available Assets</h4>
                  <p className="text-gray-300">{broker.assets}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Spreads</h4>
                  <p className="text-gray-300">{broker.spreads}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Leverage</h4>
                  <p className="text-gray-300">{broker.leverage}</p>
                </div>
              </div>

              <div className="space-y-6">
                <h3 className="text-xl font-semibold text-cyan-300 mb-4">Account & Support</h3>
                
                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Account Types</h4>
                  <p className="text-gray-300">{broker.accountTypes}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Deposit Methods</h4>
                  <p className="text-gray-300">{broker.depositMethods}</p>
                </div>

                <div>
                  <h4 className="font-medium text-cyan-300 mb-1">Withdrawal Methods</h4>
                  <p className="text-gray-300">{broker.withdrawalMethods}</p>
                </div>

                <div className="flex items-start gap-3">
                  <Award className="w-6 h-6 text-yellow-400 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Bonus & Promotions</h4>
                    <p className="text-gray-300">{broker.bonus}</p>
                  </div>
                </div>

                <div className="flex items-start gap-3">
                  <Phone className="w-6 h-6 text-cyan-400 mt-1 flex-shrink-0" />
                  <div>
                    <h4 className="font-medium text-cyan-300 mb-1">Customer Support</h4>
                    <p className="text-gray-300">{broker.support}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Pros and Cons */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              <div>
                <h3 className="text-xl font-semibold text-green-400 mb-4">Pros</h3>
                <ul className="space-y-2">
                  {broker.pros.map((pro, index) => (
                    <li key={index} className="flex items-center gap-2 text-gray-300">
                      <div className="w-2 h-2 bg-green-400 rounded-full flex-shrink-0"></div>
                      {pro}
                    </li>
                  ))}
                </ul>
              </div>
              <div>
                <h3 className="text-xl font-semibold text-red-400 mb-4">Cons</h3>
                <ul className="space-y-2">
                  {broker.cons.map((con, index) => (
                    <li key={index} className="flex items-center gap-2 text-gray-300">
                      <div className="w-2 h-2 bg-red-400 rounded-full flex-shrink-0"></div>
                      {con}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* CTA Section */}
            <div className="mt-12 text-center p-8 bg-gradient-to-r from-cyan-900/20 to-purple-900/20 rounded-lg border border-cyan-500/20">
              <h3 className="text-2xl font-bold text-cyan-300 mb-4">Ready to Start Trading?</h3>
              <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
                Join thousands of traders who have chosen {broker.name} for their trading journey. 
                Start with a minimum deposit of {broker.minDeposit} and access professional trading tools.
              </p>
              <a
                href={broker.affiliateUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="bg-gradient-to-r from-cyan-600 to-purple-600 hover:from-cyan-500 hover:to-purple-500 text-white px-10 py-4 rounded-lg font-semibold text-lg transition-all duration-300 inline-flex items-center gap-3 shadow-lg hover:shadow-cyan-500/30 transform hover:scale-105"
              >
                Open Account Now
                <ExternalLink className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default BrokerDetail;