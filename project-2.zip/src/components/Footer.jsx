import React from 'react';

const Footer = () => {
  return (
    <footer className="bg-gradient-to-r from-slate-900 via-purple-900 to-slate-900 border-t border-cyan-500/30">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          <div className="col-span-1 md:col-span-1">
            <h3 className="text-2xl font-bold text-white mb-4">
            </h3>
            <p className="text-gray-300 mb-4 leading-relaxed">
              Compare trusted trading platforms and brokers side by side.
            </p>
            <p className="text-gray-300 leading-relaxed">
              Find the best broker for your trading style, faster and simpler.
            </p>
            <div className="mt-6">
              <p className="text-cyan-300 font-medium mb-2">Contact us:</p>
              <p className="text-gray-300">gleamifycustomercare.com</p>
            </div>
          </div>

          <div>
            <h4 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-6">OUR MISSION</h4>
            <p className="text-gray-300 leading-relaxed mb-4">
              Forex traders should be smart enough not just to make lucrative trades, but also to choose a broker who can best meet their requirements. Our mission is to help investors to lower risks by providing unbiased reviews and ratings.
            </p>
          </div>

          <div>
            <h4 className="text-2xl font-bold bg-gradient-to-r from-cyan-400 to-purple-400 bg-clip-text text-transparent mb-6">RISK WARNING</h4>
            <p className="text-gray-300 leading-relaxed">
              All investments involve risks including possible loss of principal. Forex, binary options and cryptocurrencies are highly speculative assets. Trading CFDs carries a risk of losing money due to leverage. 78.6% of retail investor accounts lose money when trading CFDs.
            </p>
          </div>
        </div>

        <div className="border-t border-cyan-500/30 mt-8 pt-8">
          <div className="text-center">
            <p className="text-gray-300 text-sm">
              © 2025 Best Broker Radar. All rights reserved.
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;